import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { isAdmin, sanitizeFilename, validateImageFile } from "../../../lib/auth";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const BUCKET = "atelier";

export const config = {
  maxDuration: 60,
};

const IMAGE_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp", ".gif"];

const ALLOWED_PATCH_FIELDS = ["title", "description", "prompt", "category", "universe", "accent", "size"] as const;

function getAdminClient() {
  return createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });
}

export async function GET() {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return NextResponse.json({ images: [], db_status: "error", db_error: "Configuration manquante" });
  }

  const adminClient = getAdminClient();

  try {
    // List all files from Supabase Storage
    const { data: files, error: listError } = await adminClient.storage
      .from(BUCKET)
      .list();

    if (listError) {
      // Bucket may not exist yet
      return NextResponse.json({
        images: [],
        db_status: "warning",
        db_error: listError.message,
      });
    }

    // Get Supabase DB metadata
    let dbMeta: { filename: string; [key: string]: unknown }[] = [];
    try {
      const { data } = await adminClient.from("atelier").select("*");
      if (data) dbMeta = data;
    } catch {
      // Table may not exist — not fatal
    }

    const metaMap = new Map(dbMeta.map((m) => [m.filename, m]));

    const imageFiles = (files || []).filter((f: { name: string }) =>
      IMAGE_EXTENSIONS.some((ext) => f.name.toLowerCase().endsWith(ext))
    );

    const storageApi = adminClient.storage.from(BUCKET);

    const images = imageFiles.map((f: { name: string }) => {
      const meta = metaMap.get(f.name);
      const { data: urlData } = storageApi.getPublicUrl(f.name);
      return {
        id: meta?.id || null,
        filename: f.name,
        url: urlData?.publicUrl || `/atelier/${f.name}`,
        title:
          meta?.title ||
          f.name
            .replace(/\.[^.]+$/, "")
            .replace(/[-_]/g, " ")
            .replace(/\b\w/g, (c) => c.toUpperCase()),
        description: meta?.description || "",
        prompt: meta?.prompt || "",
        category:
          meta?.category ||
          (f.name.toLowerCase().includes("portrait") ? "Portrait" : "Création"),
        universe: meta?.universe || "Guilde Otaku",
        accent: meta?.accent || "#8b5cf6",
        size: meta?.size || "cell-normal",
        has_db_record: !!meta,
      };
    });

    return NextResponse.json({ images, db_status: "connected", db_error: null });
  } catch {
    return NextResponse.json(
      { images: [], db_status: "error", db_error: "Erreur serveur" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  if (!isAdmin(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return NextResponse.json({ error: "Configuration manquante" }, { status: 500 });
  }

  try {
    const formData = await req.formData();
    const files = formData.getAll("files") as File[];
    if (files.length === 0) {
      const singleFile = formData.get("file") as File | null;
      if (singleFile) files.push(singleFile);
    }
    if (files.length === 0) {
      return NextResponse.json({ error: "Aucun fichier" }, { status: 400 });
    }

    const adminClient = getAdminClient();
    const results: { filename: string; url: string; success: boolean; error?: string }[] = [];

    for (const file of files) {
      const validation = await validateImageFile(file);
      if (!validation.valid) {
        results.push({ filename: file.name, url: "", success: false, error: validation.error });
        continue;
      }

      const buffer = Buffer.from(await file.arrayBuffer());
      const finalName = sanitizeFilename(file.name);

      const { error: uploadError } = await adminClient.storage
        .from(BUCKET)
        .upload(finalName, buffer, {
          contentType: file.type || "image/jpeg",
          upsert: true,
        });

      if (uploadError) {
        results.push({ filename: finalName, url: "", success: false, error: "Erreur d'upload" });
        continue;
      }

      const title = finalName
        .replace(/\.[^.]+$/, "")
        .replace(/[-_]/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase());

      await adminClient.from("atelier").upsert(
        {
          filename: finalName,
          title,
          category: finalName.toLowerCase().includes("portrait") ? "Portrait" : "Création",
        },
        { onConflict: "filename" }
      );

      const { data } = adminClient.storage.from(BUCKET).getPublicUrl(finalName);
      results.push({ filename: finalName, url: data.publicUrl, success: true });
    }

    const successCount = results.filter(r => r.success).length;
    const failCount = results.filter(r => !r.success).length;

    return NextResponse.json({
      success: failCount === 0,
      results,
      summary: `${successCount} uploadé(s)${failCount > 0 ? `, ${failCount} échoué(s)` : ""}`,
    });
  } catch {
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  if (!isAdmin(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return NextResponse.json({ error: "Supabase env vars missing" }, { status: 500 });
  }

  try {
    const body = await req.json();
    const { filename } = body;
    if (!filename) {
      return NextResponse.json({ error: "Filename manquant" }, { status: 400 });
    }

    const updates: Record<string, unknown> = { filename };
    for (const key of ALLOWED_PATCH_FIELDS) {
      if (body[key] !== undefined) updates[key] = body[key];
    }

    const adminClient = getAdminClient();
    const { error } = await adminClient
      .from("atelier")
      .upsert(updates, { onConflict: "filename" });
    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  if (!isAdmin(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return NextResponse.json({ error: "Supabase env vars missing" }, { status: 500 });
  }

  try {
    const { filename } = await req.json();
    if (!filename) {
      return NextResponse.json({ error: "Nom de fichier manquant" }, { status: 400 });
    }

    const adminClient = getAdminClient();

    // Delete from Supabase Storage
    await adminClient.storage.from(BUCKET).remove([filename]);

    // Delete from DB
    await adminClient.from("atelier").delete().eq("filename", filename);

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
