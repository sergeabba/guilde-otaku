"use client";

import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { Member } from "../../data/members";
import { useState } from "react";
import type { ViewMode } from "../types";
import { rankAccents, darkRanks, rankJapanese, Rank } from "../config/ranks";
import { User, Sword, Cake, Trophy } from "lucide-react";
import VideoPlayer from "./VideoPlayer";

export default function MemberCard({ member, index, viewMode, onClick, isMobile }: {
  member: Member; index: number; viewMode: ViewMode; onClick: () => void; isMobile?: boolean;
}) {
  const [imgErrorReal, setImgErrorReal] = useState(false);
  const [imgErrorAnime, setImgErrorAnime] = useState(false);
  const [hovered, setHovered] = useState(false);

  const accent = rankAccents[member.rank as keyof typeof rankAccents] ?? "#c9a84c";
  const isDark  = darkRanks.includes(member.rank as any);
  const isAnime   = viewMode === "anime";
  const videoSrc  = isAnime ? member.animeVideo : member.photoVideo;
  const photoSrc  = isAnime ? member.animeChar : member.photo;
  const hasError  = isAnime ? imgErrorAnime : imgErrorReal;
  const onError   = isAnime ? () => setImgErrorAnime(true) : () => setImgErrorReal(true);

  const jpRank = rankJapanese[member.rank as Rank] ?? "";
  const tapeColor = index % 4 === 0 ? "rose" : index % 4 === 1 ? "vert" : index % 4 === 2 ? "bleu" : "gold";
  const idleRotate = isMobile ? 0 : (index % 4 === 0 ? -1 : index % 4 === 2 ? 1 : 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 24, rotate: idleRotate }}
      animate={{ opacity: 1, y: 0, rotate: hovered ? 0 : idleRotate }}
      whileHover={isMobile ? {} : {
        y: -9,
        scale: 1.03,
        rotate: 0,
        boxShadow: `0 28px 60px rgba(0,0,0,0.4), 0 0 0 2px ${accent}, 0 0 35px ${accent}44`,
        transition: { duration: 0.35, ease: [0.23, 1, 0.32, 1] },
      }}
      transition={{ duration: 0.45, delay: index * 0.035 }}
      onClick={onClick}
      onMouseEnter={() => !isMobile && setHovered(true)}
      onMouseLeave={() => !isMobile && setHovered(false)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick(); } }}
      style={{
        cursor: "pointer",
        borderRadius: isMobile ? "14px" : "18px",
        overflow: "hidden",
        position: "relative",
        aspectRatio: isMobile ? "3/4" : "2/3",
        boxShadow: isDark
          ? "0 8px 24px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.08)"
          : "0 8px 24px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.06)",
        background: isDark ? "#0d0d14" : "#f5f5f2",
        transformStyle: "preserve-3d",
      }}
    >
      {/* Scotch tape — scrapbook collector accent */}
      <div
        className={`scotch ${tapeColor}`}
        style={{
          position: "absolute",
          top: "-5px",
          left: "50%",
          transform: `translateX(-50%) rotate(${index % 2 === 0 ? "-1.5deg" : "2deg"})`,
          width: isMobile ? "44px" : "58px",
          height: isMobile ? "14px" : "18px",
          zIndex: 10,
          pointerEvents: "none",
        }}
      />

      <AnimatePresence mode="wait">
        <motion.div
          key={viewMode}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.97 }}
          transition={{ duration: 0.35 }}
          style={{ position: "absolute", inset: 0 }}
        >
          {videoSrc ? (
            <VideoPlayer src={videoSrc} fit="cover" objectPosition="smart" fullscreenBtn />
          ) : !hasError ? (
            <Image
              src={photoSrc}
              alt={`${member.name} — ${isAnime ? "personnage anime" : "photo"}`}
              fill
              sizes={isMobile ? "50vw" : "(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 230px"}
              priority={index < 4}
              className="object-cover object-top transition-transform duration-700 ease-out"
              style={{ transform: hovered ? "scale(1.04)" : "scale(1)" }}
              onError={onError}
            />
          ) : (
            <div style={{ position: "absolute", inset: 0, background: isDark ? "#0d0d14" : "#f5f5f3", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "8px" }}>
              <div style={{ width: "48px", height: "48px", borderRadius: "50%", background: `${accent}20`, border: `2px solid ${accent}40`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {isAnime ? <Sword size={20} color={accent} /> : <User size={20} color={accent} />}
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Holographic reflection sheen on hover */}
      <motion.div
        animate={{
          opacity: hovered ? 1 : 0,
          transform: hovered ? "translateX(150%) rotate(25deg)" : "translateX(-150%) rotate(25deg)",
        }}
        transition={{ duration: 0.75, ease: "easeInOut" }}
        style={{
          position: "absolute",
          inset: "-60% -40%",
          background: "linear-gradient(90deg, transparent 30%, rgba(255,255,255,0.18) 48%, rgba(255,215,0,0.24) 52%, transparent 70%)",
          pointerEvents: "none",
          zIndex: 6,
        }}
      />

      {/* Shadow gradient for text readability */}
      <div style={{ position: "absolute", inset: 0, background: isDark ? "linear-gradient(to bottom, transparent 30%, rgba(0,0,0,0.4) 60%, rgba(0,0,0,0.96) 100%)" : "linear-gradient(to bottom, transparent 30%, rgba(0,0,0,0.3) 60%, rgba(0,0,0,0.88) 100%)", opacity: hasError ? 0 : 1, pointerEvents: "none", zIndex: 2 }} />

      {/* Manga Screentone Texture */}
      <div
        className="manga-screentone"
        style={{
          position: "absolute",
          inset: 0,
          opacity: hovered ? 0.08 : 0.03,
          color: "#fff",
          pointerEvents: "none",
          zIndex: 3,
          transition: "opacity 0.3s ease",
        }}
      />

      {/* Top badges: Tampon stamp on top left */}
      <div style={{ position: "absolute", top: isMobile ? "8px" : "12px", left: isMobile ? "8px" : "12px", zIndex: 5, pointerEvents: "none" }}>
        <span
          className="tampon"
          style={{
            fontSize: isMobile ? "8px" : "9px",
            padding: "2px 7px",
            borderColor: accent,
            color: accent,
            background: "rgba(0,0,0,0.55)",
            backdropFilter: "blur(6px)",
            letterSpacing: "0.12em",
            display: "inline-flex",
            alignItems: "center",
            gap: "5px",
          }}
        >
          <span>{member.rank}</span>
          {jpRank && (
            <span style={{ fontSize: "8px", opacity: 0.75, fontFamily: "sans-serif" }}>
              『{jpRank}』
            </span>
          )}
        </span>
      </div>

      {/* Watermark ID on top right */}
      <div style={{
        position: "absolute", top: isMobile ? "2px" : "6px", right: isMobile ? "6px" : "12px",
        fontFamily: "'Barlow Condensed', sans-serif",
        fontSize: isMobile ? "36px" : "64px", fontWeight: 900,
        color: accent, opacity: hovered ? 0.3 : 0.12,
        lineHeight: 1, letterSpacing: "-0.05em", pointerEvents: "none",
        zIndex: 3,
        transition: "opacity 0.3s",
      }}>
        {String(member.id).padStart(2, "0")}
      </div>

      {/* Info bottom */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: isMobile ? "12px" : "18px 16px", zIndex: 4 }}>
        {member.badge && (
          <div style={{
            display: "inline-flex", alignItems: "center", gap: "4px",
            marginBottom: "6px",
            background: "linear-gradient(90deg, #b8860b 0%, #ffd700 50%, #b8860b 100%)",
            padding: isMobile ? "2px 6px" : "3px 8px", borderRadius: "4px",
            boxShadow: "0 4px 10px rgba(0,0,0,0.5)", border: "1px solid rgba(255,255,255,0.4)"
          }}>
            <Trophy size={isMobile ? 10 : 11} color="#000" strokeWidth={3} />
            <span style={{ fontSize: isMobile ? "9px" : "10px", fontWeight: 900, color: "#000", textTransform: "uppercase", fontFamily: "'Barlow Condensed', sans-serif" }}>
              {member.badge}
            </span>
          </div>
        )}

        <div className="font-bricolage" style={{ fontSize: isMobile ? "18px" : "24px", fontWeight: 800, color: "#fff", lineHeight: 1.05, textTransform: "uppercase", letterSpacing: "-0.02em", textShadow: "0 2px 14px rgba(0,0,0,0.7)" }}>
          {member.name}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "5px", fontFamily: "'Barlow Condensed', sans-serif", fontSize: isMobile ? "10px" : "12px", fontWeight: 700, color: "rgba(255,255,255,0.72)", marginTop: "4px" }}>
          <Cake size={isMobile ? 10 : 11} color={accent} />
          {member.birthday}
        </div>
      </div>
    </motion.div>
  );
}
